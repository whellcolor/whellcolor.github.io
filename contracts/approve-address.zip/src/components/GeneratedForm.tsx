import { useMemo, useState } from 'react';

import { Card, CardContent } from '@openzeppelin/ui-components';
import { ContractActionBar, ContractStateWidget, TransactionForm } from '@openzeppelin/ui-renderer';
import type {
  ContractAdapter,
  ContractSchema,
  ExecutionConfig,
  RenderFormSchema,
} from '@openzeppelin/ui-types';
import { cn } from '@openzeppelin/ui-utils';

// Props for GeneratedForm
interface GeneratedFormProps {
  adapter: ContractAdapter;
  isWalletConnected?: boolean;
}

/**
 * Generated Transaction Form for approve_address_uint256
 *
 * This component renders a form for interacting with a blockchain contract.
 * It uses the shared renderer package which ensures consistent behavior
 * with the preview in the builder app.
 */
export default function GeneratedForm({ adapter, isWalletConnected }: GeneratedFormProps) {
  // TODO: Enable this useEffect as a fallback?
  // If the adapter supports runtime schema loading (e.g., via Etherscan)
  // and the injected schema is missing or invalid, this could attempt to load it.
  /*
  const [contractSchema, setContractSchema] = useState<ContractSchema | null>(null);
  */
  const [isWidgetVisible, setIsWidgetVisible] = useState(false);
  const [loadError, _setLoadError] = useState<Error | null>(null);

  // Form schema generated from the builder and transformed by FormSchemaFactory
  // Memoized to maintain stable reference across re-renders and prevent form resets
  const formSchema: RenderFormSchema = useMemo(() => {
    return {
      layout: {
        columns: 1,
        spacing: 'normal',
        labelPosition: 'top',
      },
      validation: {
        mode: 'onChange',
        showErrors: 'inline',
      },
      theme: {},
      functionId: 'approve_address_uint256',
      title: 'Approve Form',
      description: 'Form for interacting with the Approve function.',
      contractAddress: '0x85e23b94e7F5E9cC1fF78BCe78cfb15B81f0DF00',
      id: 'form-approve_address_uint256',
      fields: [
        {
          id: 'field-84hwq4x',
          name: 'spender',
          label: 'Spender',
          type: 'blockchain-address',
          placeholder: 'Enter Spender',
          helperText: '',
          defaultValue: '',
          validation: {
            required: true,
          },
          width: 'full',
          transforms: {},
          originalParameterType: 'address',
        },
        {
          id: 'field-t7qq89e',
          name: 'value',
          label: 'Value',
          type: 'bigint',
          placeholder: 'Enter Value',
          helperText: '',
          defaultValue: '',
          validation: {
            required: true,
          },
          width: 'full',
          transforms: {},
          originalParameterType: 'uint256',
        },
      ],
      submitButton: {
        text: 'Execute Approve Form',
        loadingText: 'Processing...',
        variant: 'primary',
      },
      defaultValues: {
        spender: '',
        value: '',
      },
    };
  }, []);

  // Contract schema injected by generator (loaded or imported by the user)
  // Memoized to maintain stable reference across re-renders and prevent form resets
  const contractSchema: ContractSchema = useMemo(() => {
    return {
      ecosystem: 'evm',
      name: 'ContractFromABI',
      address: '0x85e23b94e7F5E9cC1fF78BCe78cfb15B81f0DF00',
      functions: [
        {
          id: 'DOMAIN_SEPARATOR_',
          name: 'DOMAIN_SEPARATOR',
          displayName: 'D O M A I N_ S E P A R A T O R',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'bytes32',
              displayName: 'Parameter (bytes32)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'allowance_address_address',
          name: 'allowance',
          displayName: 'Allowance',
          inputs: [
            {
              name: 'owner',
              type: 'address',
              displayName: 'Owner',
            },
            {
              name: 'spender',
              type: 'address',
              displayName: 'Spender',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'approve_address_uint256',
          name: 'approve',
          displayName: 'Approve',
          inputs: [
            {
              name: 'spender',
              type: 'address',
              displayName: 'Spender',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'approveAndCall_address_uint256',
          name: 'approveAndCall',
          displayName: 'Approve And Call',
          inputs: [
            {
              name: 'spender',
              type: 'address',
              displayName: 'Spender',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'approveAndCall_address_uint256_bytes',
          name: 'approveAndCall',
          displayName: 'Approve And Call',
          inputs: [
            {
              name: 'spender',
              type: 'address',
              displayName: 'Spender',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
            {
              name: 'data',
              type: 'bytes',
              displayName: 'Data',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'balanceOf_address',
          name: 'balanceOf',
          displayName: 'Balance Of',
          inputs: [
            {
              name: 'account',
              type: 'address',
              displayName: 'Account',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'burn_uint256',
          name: 'burn',
          displayName: 'Burn',
          inputs: [
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'burnFrom_address_uint256',
          name: 'burnFrom',
          displayName: 'Burn From',
          inputs: [
            {
              name: 'account',
              type: 'address',
              displayName: 'Account',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'decimals_',
          name: 'decimals',
          displayName: 'Decimals',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint8',
              displayName: 'Parameter (uint8)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'eip712Domain_',
          name: 'eip712Domain',
          displayName: 'Eip712 Domain',
          inputs: [],
          outputs: [
            {
              name: 'fields',
              type: 'bytes1',
              displayName: 'Fields',
            },
            {
              name: 'name',
              type: 'string',
              displayName: 'Name',
            },
            {
              name: 'version',
              type: 'string',
              displayName: 'Version',
            },
            {
              name: 'chainId',
              type: 'uint256',
              displayName: 'Chain Id',
            },
            {
              name: 'verifyingContract',
              type: 'address',
              displayName: 'Verifying Contract',
            },
            {
              name: 'salt',
              type: 'bytes32',
              displayName: 'Salt',
            },
            {
              name: 'extensions',
              type: 'uint256[]',
              displayName: 'Extensions',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'flashFee_address_uint256',
          name: 'flashFee',
          displayName: 'Flash Fee',
          inputs: [
            {
              name: 'token',
              type: 'address',
              displayName: 'Token',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'flashLoan_address_address_uint256_bytes',
          name: 'flashLoan',
          displayName: 'Flash Loan',
          inputs: [
            {
              name: 'receiver',
              type: 'address',
              displayName: 'Receiver',
            },
            {
              name: 'token',
              type: 'address',
              displayName: 'Token',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
            {
              name: 'data',
              type: 'bytes',
              displayName: 'Data',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'maxFlashLoan_address',
          name: 'maxFlashLoan',
          displayName: 'Max Flash Loan',
          inputs: [
            {
              name: 'token',
              type: 'address',
              displayName: 'Token',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'mint_address_uint256',
          name: 'mint',
          displayName: 'Mint',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'amount',
              type: 'uint256',
              displayName: 'Amount',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'name_',
          name: 'name',
          displayName: 'Name',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'nonces_address',
          name: 'nonces',
          displayName: 'Nonces',
          inputs: [
            {
              name: 'owner',
              type: 'address',
              displayName: 'Owner',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'owner_',
          name: 'owner',
          displayName: 'Owner',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'pause_',
          name: 'pause',
          displayName: 'Pause',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'paused_',
          name: 'paused',
          displayName: 'Paused',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'permit_address_address_uint256_uint256_uint8_bytes32_bytes32',
          name: 'permit',
          displayName: 'Permit',
          inputs: [
            {
              name: 'owner',
              type: 'address',
              displayName: 'Owner',
            },
            {
              name: 'spender',
              type: 'address',
              displayName: 'Spender',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
            {
              name: 'deadline',
              type: 'uint256',
              displayName: 'Deadline',
            },
            {
              name: 'v',
              type: 'uint8',
              displayName: 'V',
            },
            {
              name: 'r',
              type: 'bytes32',
              displayName: 'R',
            },
            {
              name: 's',
              type: 'bytes32',
              displayName: 'S',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'renounceOwnership_',
          name: 'renounceOwnership',
          displayName: 'Renounce Ownership',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'supportsInterface_bytes4',
          name: 'supportsInterface',
          displayName: 'Supports Interface',
          inputs: [
            {
              name: 'interfaceId',
              type: 'bytes4',
              displayName: 'Interface Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'symbol_',
          name: 'symbol',
          displayName: 'Symbol',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'totalSupply_',
          name: 'totalSupply',
          displayName: 'Total Supply',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'transfer_address_uint256',
          name: 'transfer',
          displayName: 'Transfer',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferAndCall_address_uint256',
          name: 'transferAndCall',
          displayName: 'Transfer And Call',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferAndCall_address_uint256_bytes',
          name: 'transferAndCall',
          displayName: 'Transfer And Call',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
            {
              name: 'data',
              type: 'bytes',
              displayName: 'Data',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferFrom_address_address_uint256',
          name: 'transferFrom',
          displayName: 'Transfer From',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferFromAndCall_address_address_uint256_bytes',
          name: 'transferFromAndCall',
          displayName: 'Transfer From And Call',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
            {
              name: 'data',
              type: 'bytes',
              displayName: 'Data',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferFromAndCall_address_address_uint256',
          name: 'transferFromAndCall',
          displayName: 'Transfer From And Call',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'value',
              type: 'uint256',
              displayName: 'Value',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferOwnership_address',
          name: 'transferOwnership',
          displayName: 'Transfer Ownership',
          inputs: [
            {
              name: 'newOwner',
              type: 'address',
              displayName: 'New Owner',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'unpause_',
          name: 'unpause',
          displayName: 'Unpause',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
      ],
    };
  }, []);

  // Execution configuration selected in the builder
  // Memoized to maintain stable reference across re-renders
  const executionConfig: ExecutionConfig | undefined = useMemo(() => {
    return {
      method: 'eoa',
      allowAny: true,
    };
  }, []);

  const contractAddress = formSchema.contractAddress;

  // TODO: Enable this useEffect as a fallback?
  // If the adapter supports runtime schema loading (e.g., via Etherscan)
  // and the injected schema is missing or invalid, this could attempt to load it.
  /*
  useEffect(() => {
    setLoadError(null);
    setContractSchema(null);

    if (contractAddress) {
      adapter
        .loadContract(contractAddress)
        .then(setContractSchema)
        .catch((err: unknown) => {
          // Catch error during contract loading
          logger.error('GeneratedForm', 'Error loading contract schema:', err);
          // Create a new Error object if caught value is not already one
          const errorToSet =
            err instanceof Error ? err : new Error('Failed to load contract state');
          setLoadError(errorToSet);
          setContractSchema(null);
        });
    } else {
      setContractSchema(null);
    }
  }, [contractAddress, adapter]);
  */

  // Decide which schema to use: prioritize injected, fallback maybe later?
  const schemaToUse = contractSchema; // Sticking to injected schema for now

  const toggleWidget = () => {
    setIsWidgetVisible((prev: boolean) => !prev);
  };

  return (
    <div className="space-y-6">
      {/* Contract Action Bar - consistent with builder app */}
      {adapter.networkConfig && (
        <ContractActionBar
          networkConfig={adapter.networkConfig}
          contractAddress={contractAddress}
          onToggleContractState={toggleWidget}
          isWidgetExpanded={isWidgetVisible}
        />
      )}

      <div className="flex gap-4">
        {/* Contract State Widget on the left side - always mounted to prevent remount churn */}
        {contractAddress && (
          <div
            className={cn(
              'shrink-0 transition-all',
              isWidgetVisible ? 'md:w-80 md:mr-6' : 'md:w-0'
            )}
          >
            <div className="sticky top-4">
              <ContractStateWidget
                contractSchema={schemaToUse}
                contractAddress={contractAddress}
                adapter={adapter}
                isVisible={isWidgetVisible}
                onToggle={toggleWidget}
                error={loadError}
              />
            </div>
          </div>
        )}

        {/* Main form on the right side */}
        <div className="flex-1">
          <Card>
            <CardContent className="space-y-4">
              <TransactionForm
                schema={formSchema}
                contractSchema={contractSchema}
                adapter={adapter}
                isWalletConnected={isWalletConnected}
                executionConfig={executionConfig}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
